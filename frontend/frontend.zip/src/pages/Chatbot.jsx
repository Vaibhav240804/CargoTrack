import React from 'react';

const Chatbot = () => {
    return (
        <div>
            Hello
        </div>
    );
};

export default Chatbot;